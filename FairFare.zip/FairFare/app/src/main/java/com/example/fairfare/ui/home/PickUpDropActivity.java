package com.example.fairfare.ui.home;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fairfare.R;
import com.example.fairfare.networking.ApiClient;
import com.example.fairfare.ui.home.pojo.GetSaveLocationResponsePOJO;
import com.example.fairfare.ui.home.pojo.SaveLocationResponsePojo;
import com.example.fairfare.ui.otp.OtpAvtivity;
import com.example.fairfare.utils.Constants;
import com.example.fairfare.utils.PreferencesManager;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PickUpDropActivity extends FragmentActivity implements OnMapReadyCallback, PlacesAutoCompleteAdapter.ClickListener {
    private GoogleMap mMap;
    double currentLatitude;
    double currentLongitude;
    Bundle extras;
    @BindView(R.id.toolbar)
    Toolbar mToolbar;

    Marker marker;

    @BindView(R.id.homeView)
    LinearLayout homeView;

    @BindView(R.id.lladdress)
    LinearLayout lladdress;


    @BindView(R.id.custom_title)
    TextView custom_title;

    @BindView(R.id.tv_searches)
    TextView tv_searches;

    @BindView(R.id.tv_saved)
    TextView tv_saved;


    @BindView(R.id.tv_recent)
    TextView tv_recent;

    @BindView(R.id.tv_view_search)
    TextView tv_view_search;


    @BindView(R.id.tv_view_saved)
    TextView tv_view_saved;


    @BindView(R.id.tv_view_recent)
    TextView tv_view_recent;


    @BindView(R.id.tvAddress)
    TextView tvAddress;


    @BindView(R.id.edt_pick_up_drop)
    EditText edt_pick_up_drop;

    SharedPreferences sharedpreferences;
    public static final String mypreference = "mypref";
    public static final String SourceLat = "SourceLat";
    public static final String SourceLong = "SourceLong";
    public static final String DestinationLat = "DestinationLat";
    public static final String DestinationLong = "DestinationLong";
    SharedPreferences.Editor editor;

    String token;

    PreferencesManager preferencesManager;

    private PlacesAutoCompleteAdapter mAutoCompleteAdapter;
    private RecyclerView recyclerView;

    private List<GetSaveLocationResponsePOJO.LocationsItem> savedLocationList = new ArrayList<>();
    RecyclerViewAdapter recyclerViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_up_drop);
        ButterKnife.bind(this);
        setStatusBarGradiant(this);
        PreferencesManager.initializeInstance(PickUpDropActivity.this);
        preferencesManager = PreferencesManager.getInstance();

        Places.initialize(this, getResources().getString(R.string.google_maps_key));
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view_fragment);


        edt_pick_up_drop.addTextChangedListener(filterTextWatcher);

        mAutoCompleteAdapter = new PlacesAutoCompleteAdapter(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        mAutoCompleteAdapter.setClickListener(this);
        recyclerView.setAdapter(mAutoCompleteAdapter);
        mAutoCompleteAdapter.notifyDataSetChanged();


        sharedpreferences = getSharedPreferences(mypreference, Context.MODE_PRIVATE);
        editor = sharedpreferences.edit();
        homeView.setVisibility(View.VISIBLE);
        lladdress.setVisibility(View.GONE);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        Intent intent = getIntent();
        extras = intent.getExtras();
        if (extras != null) {
            currentLatitude = extras.getDouble("currentLatitude");
            currentLongitude = extras.getDouble("currentLongitude");


        }
        setToolbar();
    }

    private TextWatcher filterTextWatcher = new TextWatcher() {
        public void afterTextChanged(Editable s) {
            if (!s.toString().equals("")) {
                mAutoCompleteAdapter.getFilter().filter(s.toString());
                if (recyclerView.getVisibility() == View.GONE) {
                    recyclerView.setVisibility(View.VISIBLE);
                }
            } else {
                if (recyclerView.getVisibility() == View.VISIBLE) {
                   // recyclerView.setVisibility(View.GONE);
                }
            }
        }

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
    };

    private void setToolbar() {
        mToolbar.setNavigationOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                    }
                });
        mToolbar.setTitle("");
        custom_title.setText(extras.getString("Toolbar_Title"));
    }

    @OnClick(R.id.tv_locateonmap)
    void locatemap() {
        homeView.setVisibility(View.GONE);
        lladdress.setVisibility(View.VISIBLE);
    }


    @OnClick(R.id.tv_searches)
    void search() {

        tv_view_recent.setBackgroundColor(Color.GRAY);
        tv_view_saved.setBackgroundColor(Color.GRAY);
        tv_view_search.setBackgroundColor(Color.RED);

        edt_pick_up_drop.addTextChangedListener(filterTextWatcher);
        mAutoCompleteAdapter = new PlacesAutoCompleteAdapter(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        mAutoCompleteAdapter.setClickListener(this);
        recyclerView.setAdapter(mAutoCompleteAdapter);
        mAutoCompleteAdapter.notifyDataSetChanged();
    }


    @OnClick(R.id.tv_saved)
    void saved() {

        tv_view_recent.setBackgroundColor(Color.GRAY);
        tv_view_saved.setBackgroundColor(Color.RED);
        tv_view_search.setBackgroundColor(Color.GRAY);

       // String sds = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiMDEwZjBlY2JjMmIwOTNmN2Q4NWI4ZmFmNzNiODY4YTAwNjdiOTJmYzRkNWQ4MmEyMWQ0MDVmNTk0Yjc4NThlM2EwZGVmYWZjYjljYmNmOTkiLCJpYXQiOjE2MDIxNjU2MDgsIm5iZiI6MTYwMjE2NTYwOCwiZXhwIjoxNjMzNzAxNjA4LCJzdWIiOiIxNSIsInNjb3BlcyI6W119.aFkHnjcx9gcpheTfhiPhDOgp9_bm63ZX_2_T6VVlhbavsRarDmx9tjz0PXQX54EonDYyZ8MHbAq-FHM7wBAj5qBuuzHRKIr2ofw-rxC0Q_wRouxNckT0b3Jja1FzozYYNzOn740xLA19YNnUmsZoyl0ELs0ZNjs401_KBL3TYUe3rqZVFCZqqUqxkaUGKVAn25TIp71kG7R0rPaqZCQd9_1UiKJctoOy2Cxhmlfy6s1ihAL4PhLz9bZ90jDPGAPFhC47vNM83hY0U-DydApeGN3xBT0QATe7z6sX7DlnWSB35x3EE9ySIXT-3l0o0COQOzr7hol0fhVpBEf0oYcwbiMQyQl3Ak4Aixa217D2mPsDupK0bMAiTIRPC8qE63yXI2u3vFA57be5OR6JV_-3PxdmIJ8mpHBQpgWjY9H7_EG36s2QvYoArrquFDtIduff0K_MSkM_qju0Zt7x4B6ulliDYnKE0T0xR77_31MHZK9QpdW3cWmxDORg9sdSi9c6GxHrR-f7SbJmWcTLaxeM1p5PTGjAfzeHqU3CYId8vV9MoEYraePrzLywSpHVNJhk68gu490PIPH-xy-GhwulKeNbpEMlfYiTSzAqGSjl3cPDWcNZCWoJKPMG4s6KQ-4X6Ijcczq8Pxsdz4EWPRax_AC0vf0-egGXEFboBqjKol8";

        String token = preferencesManager.getStringValue(Constants.SHARED_PREFERENCE_LOGIN_TOKEN);
        (ApiClient.getClient().getSavedLocation("Bearer " + token)).enqueue(new Callback<GetSaveLocationResponsePOJO>() {
            @Override
            public void onResponse(Call<GetSaveLocationResponsePOJO> call, Response<GetSaveLocationResponsePOJO> response) {
                savedLocationList = response.body().getData().getLocations();
                recyclerViewAdapter = new RecyclerViewAdapter(PickUpDropActivity.this, savedLocationList);
                recyclerView.setAdapter(recyclerViewAdapter);
            }

            @Override
            public void onFailure(Call<GetSaveLocationResponsePOJO> call, Throwable t) {
                Log.d("response", t.getStackTrace().toString());

            }
        });


    }


    @OnClick(R.id.tv_recent)
    void recent() {
        tv_view_recent.setBackgroundColor(Color.RED);
        tv_view_saved.setBackgroundColor(Color.GRAY);
        tv_view_search.setBackgroundColor(Color.GRAY);


    }


    @Override
    protected void onDestroy() {
        sharedpreferences.edit().clear().commit();
        super.onDestroy();
    }

    @OnClick(R.id.btnContinue)
    void btnContinue() {


        if (extras.getString("Toolbar_Title").equals("Pick-Up")) {

            sharedpreferences.edit().remove("SourceLat");
            sharedpreferences.edit().remove("SourceLong");
            editor.putString(SourceLat, String.valueOf(currentLatitude));
            editor.putString(SourceLong, String.valueOf(currentLongitude));

        } else {
            sharedpreferences.edit().remove("DestinationLat");
            sharedpreferences.edit().remove("DestinationLong");
            editor.putString(DestinationLat, String.valueOf(currentLatitude));
            editor.putString(DestinationLong, String.valueOf(currentLongitude));
        }

        editor.commit();
        editor.apply();


        Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
        intent.putExtra("Toolbar_Title", extras.getString("Toolbar_Title"));
        intent.putExtra("currentLatitude", currentLatitude);
        intent.putExtra("currentLongitude", currentLongitude);
        startActivity(intent);
    }

    private void setStatusBarGradiant(PickUpDropActivity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = activity.getWindow();
            Drawable background = activity.getResources().getDrawable(R.drawable.app_gradient);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(activity.getResources().getColor(android.R.color.transparent));
            window.setBackgroundDrawable(background);
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {


        mapCalled(googleMap);

    }

    private void mapCalled(GoogleMap googleMap) {

        MarkerOptions markerOptionscurrent = new MarkerOptions();
        markerOptionscurrent.position(new LatLng(currentLatitude, currentLongitude));
        String currentAddress = null;
        Geocoder geocoder = new Geocoder(PickUpDropActivity.this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(currentLatitude, currentLongitude, 1);
            if (addresses != null) {
                Address returnedAddress = addresses.get(0);
                StringBuilder strReturnedAddress = new StringBuilder();
                for (int j = 0; j <= returnedAddress.getMaxAddressLineIndex(); j++) {
                    strReturnedAddress.append(returnedAddress.getAddressLine(j));
                }
                currentAddress = strReturnedAddress.toString();
            }
        } catch (IOException e) {
        }


        mMap = googleMap;
        tvAddress.setText(currentAddress);
        markerOptionscurrent.title(currentAddress);
        googleMap.animateCamera(CameraUpdateFactory.newLatLng(new LatLng(currentLatitude, currentLongitude)));
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(currentLatitude, currentLongitude), 13.0f));
        googleMap.addMarker(markerOptionscurrent);


        googleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {

                MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.position(latLng);
                currentLatitude = latLng.latitude;
                currentLongitude = latLng.longitude;

                String street = null;
                Geocoder geocoder = new Geocoder(PickUpDropActivity.this, Locale.getDefault());
                try {
                    List<Address> addresses = geocoder.getFromLocation(currentLatitude, currentLongitude, 1);
                    if (addresses != null) {
                        Address returnedAddress = addresses.get(0);
                        StringBuilder strReturnedAddress = new StringBuilder();
                        for (int j = 0; j <= returnedAddress.getMaxAddressLineIndex(); j++) {
                            strReturnedAddress.append(returnedAddress.getAddressLine(j));
                        }
                        street = strReturnedAddress.toString();
                    }
                } catch (IOException e) {
                }
                tvAddress.setText(street);
                markerOptions.title(street);
                googleMap.clear();
                googleMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 13.0f));
                googleMap.addMarker(markerOptions);


            }
        });


    }

    @Override
    public void click(Place place) {

        currentLatitude = place.getLatLng().latitude;
        currentLongitude = place.getLatLng().longitude;

        if (extras.getString("Toolbar_Title").equals("Pick-Up")) {

            sharedpreferences.edit().remove("SourceLat");
            sharedpreferences.edit().remove("SourceLong");
            editor.putString(SourceLat, String.valueOf(currentLatitude));
            editor.putString(SourceLong, String.valueOf(currentLongitude));

        } else {
            sharedpreferences.edit().remove("DestinationLat");
            sharedpreferences.edit().remove("DestinationLong");
            editor.putString(DestinationLat, String.valueOf(currentLatitude));
            editor.putString(DestinationLong, String.valueOf(currentLongitude));
        }

        editor.commit();
        editor.apply();

        mapCalled(mMap);
        // Toast.makeText(this, place.getAddress() + ", " + place.getLatLng().latitude + place.getLatLng().longitude, Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
        intent.putExtra("Toolbar_Title", extras.getString("Toolbar_Title"));
        intent.putExtra("currentLatitude", currentLatitude);
        intent.putExtra("currentLongitude", currentLongitude);
        startActivity(intent);

    }

    @Override
    public void favClick(Place place) {
        Toast.makeText(this, "Added in fav" + place.getId(), Toast.LENGTH_SHORT).show();
        Log.d("sdsdsdskdssssdsd", place.getId());
    }
}
