package com.example.fairfare.ui.Register;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.fairfare.R;
import com.example.fairfare.networking.ApiClient;
import com.example.fairfare.ui.Login.LoginActivity;
import com.example.fairfare.ui.Login.pojo.LoginResponsepojo;
import com.example.fairfare.ui.Login.pojo.ValidationResponse;
import com.example.fairfare.ui.otp.OtpAvtivity;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.rilixtech.widget.countrycodepicker.Country;
import com.rilixtech.widget.countrycodepicker.CountryCodePicker;

import java.io.IOException;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.OnTextChanged;
import butterknife.OnTouch;

import io.michaelrocks.libphonenumber.android.NumberParseException;
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil;
import io.michaelrocks.libphonenumber.android.Phonenumber;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity implements CountryCodePicker.OnCountryChangeListener {


    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    String MobileNo, UserName, UserEmail, LoginType = "NOR", GoogleToken, CountryCode;
    String countryCode = "91";
    String countryCodeISO = "IN";
    @BindView(R.id.edit_text_register)
    EditText edit_text_register;

    @BindView(R.id.edt_email)
    EditText edt_email;

    @BindView(R.id.btnRegister)
    Button btnRegister;

    @BindView(R.id.tvEmailError)
    TextView tvEmailError;

    @BindView(R.id.tvPhoneNumberError)
    TextView tvPhoneNumberError;
    @BindView(R.id.ccpr)
    CountryCodePicker ccp;

    @BindView(R.id.tvNameError)
    TextView tvNameError;

    @BindView(R.id.sign_up)
    TextView sign_up;


    @BindView(R.id.edt_name)
    EditText edt_name;

    LoginResponsepojo loginResponsepojo;
    Country selectedCountryCode;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ButterKnife.bind(this);
        ccp.setOnCountryChangeListener(this);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            MobileNo = extras.getString("Mobile_No");
            UserName = extras.getString("UserName");
            UserEmail = extras.getString("UserEmail");
            LoginType = extras.getString("LoginType");
            GoogleToken = extras.getString("GoogleToken");
            CountryCode = extras.getString("CountryCode");
            countryCodeISO = extras.getString("countryCodeISO");

            if (!(TextUtils.isEmpty(MobileNo))) {
                edit_text_register.setText(MobileNo);
                edit_text_register.setEnabled(true);
            }
            if (!(TextUtils.isEmpty(UserEmail))) {
                edt_email.setText(UserEmail);
                edt_email.setEnabled(false);

            }


            if (!(TextUtils.isEmpty(UserName))) {
                edt_name.setText(UserName);
                edt_name.setEnabled(false);

            }

        }else {
            CountryCode="91";
        }

      //  numbervalidation ="true";
        if(TextUtils.isEmpty(MobileNo)){
            CountryCode="91";
            ccp.setCountryForNameCode("in");

        }else {
            ccp.setCountryForNameCode(countryCodeISO);
        }

        if (LoginType.equals("GGL")) {
            sign_up.setText("Please enter Phone number and Gender.");
        }

    }


    @OnClick(R.id.tvLogin)
    void tvLogin() {
        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    @OnTextChanged(R.id.edt_email)
    void edtEmail() {
        if (tvEmailError.getVisibility() == View.VISIBLE) {
            tvEmailError.setVisibility(View.GONE);
            return;
        }
    }

    @OnTextChanged(R.id.edit_text_register)
    void editPhone() {
        if (tvPhoneNumberError.getVisibility() == View.VISIBLE) {
            tvPhoneNumberError.setVisibility(View.GONE);
            return;
        }
    }


    @OnTextChanged(R.id.edt_name)
    void editName() {
        if (tvNameError.getVisibility() == View.VISIBLE) {
            tvNameError.setVisibility(View.GONE);
            return;
        }
    }


    @OnClick(R.id.btnRegister)
    void btnCLick() {
        PhoneNumberUtil phoneNumberUtil;
        Phonenumber.PhoneNumber phoneNumber = null;
        String numbervalidation = "false";
        PhoneNumberUtil.PhoneNumberType isMobile = null;
        phoneNumberUtil = PhoneNumberUtil.createInstance(this);

        try {
            phoneNumber = phoneNumberUtil.parse(edit_text_register.getText().toString().trim(), countryCodeISO.toUpperCase());
            isMobile = phoneNumberUtil.getNumberType(phoneNumber);

        } catch (NumberParseException e) {
            e.printStackTrace();
        }

        if(PhoneNumberUtil.PhoneNumberType.MOBILE==isMobile){
            numbervalidation ="true";
        }
        else if(PhoneNumberUtil.PhoneNumberType.FIXED_LINE==isMobile){
            numbervalidation ="false";

        }else {
            numbervalidation ="false";
        }

       /* try {

            phoneNumber = phoneNumberUtil.parse(edit_text_register.getText().toString(), countryCodeISO.toUpperCase());
            boolean isValid = phoneNumberUtil.isValidNumber(phoneNumber);

            numbervalidation = String.valueOf(isValid);

        } catch (NumberParseException e) {
            e.printStackTrace();
        }*/

        if (numbervalidation.equals("false")) {
            tvPhoneNumberError.setText("Please enter a valid phone no.");
            tvPhoneNumberError.setVisibility(View.VISIBLE);
        } else if (!(edt_email.getText().toString().trim().matches(emailPattern))) {
            // Toast.makeText(this, "wrong", Toast.LENGTH_LONG).show();
            tvEmailError.setText("Please enter a valid email.");
            tvEmailError.setVisibility(View.VISIBLE);
        } else if (TextUtils.isEmpty(edt_name.getText().toString())) {
            tvNameError.setText("Please enter Full Name");
            tvNameError.setVisibility(View.VISIBLE);
        } else {


            final ProgressDialog progressDialog = new ProgressDialog(RegisterActivity.this);
            progressDialog.setCancelable(false); // set cancelable to false
            progressDialog.setMessage("Please Wait"); // set message
            progressDialog.show(); // show progress dialog

            if (LoginType.equals("NOR")) {
                GoogleToken = "";
            }
            (ApiClient.getClient().login(edit_text_register.getText().toString(), "Register", "Android",
                    LoginType, countryCode, edt_name.getText().toString(), edt_email.getText().toString(), GoogleToken)).enqueue(new Callback<LoginResponsepojo>() {
                @Override
                public void onResponse(Call<LoginResponsepojo> call, Response<LoginResponsepojo> response) {
                    LoginResponsepojo loginResponsepojo = response.body();

                    if (response.code() == 200) {
                        if (loginResponsepojo.getRedirectTo().equals("Otp")) {
                            Intent intent = new Intent(getApplicationContext(), OtpAvtivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            intent.putExtra("Mobile_No", edit_text_register.getText().toString());
                            intent.putExtra("CountryCode", countryCode);
                            intent.putExtra("UserMail", edt_email.getText().toString());
                            intent.putExtra("UserName", edt_name.getText().toString());
                            intent.putExtra("LoginType", LoginType);
                            intent.putExtra("Activity", "Register");
                            intent.putExtra("GoogleToken", GoogleToken);

                            startActivity(intent);
                            finish();
                        }
                    } else {

                        Gson gson = new GsonBuilder().create();
                        ValidationResponse pojo = new ValidationResponse();

                        try {
                            pojo = gson.fromJson(response.errorBody().string(), ValidationResponse.class);
                            for (int i = 0; i < pojo.getErrors().size(); i++) {

                                if (pojo.getErrors().get(i).getKey().equals("email")) {
                                    tvEmailError.setText(pojo.getErrors().get(i).getMessage());
                                    tvEmailError.setVisibility(View.VISIBLE);
                                }

                                if (pojo.getErrors().get(i).getKey().equals("phone_no")) {
                                    tvPhoneNumberError.setText(pojo.getErrors().get(i).getMessage());
                                    tvPhoneNumberError.setVisibility(View.VISIBLE);
                                }


                            }


                        } catch (IOException exception) {
                        }


                    }


                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<LoginResponsepojo> call, Throwable t) {
                    Log.d("response", t.getStackTrace().toString());
                    progressDialog.dismiss();

                }
            });

        }

    }

    @Override
    public void onCountrySelected(Country selectedCountry) {
        selectedCountryCode = selectedCountry;

        countryCode = selectedCountry.getPhoneCode();
        countryCodeISO = selectedCountryCode.getIso();
    }
}
