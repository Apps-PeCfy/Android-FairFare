package com.example.fairfare.ui.home;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fairfare.R;
import com.example.fairfare.ui.home.pojo.GetSaveLocationResponsePOJO;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by anupamchugh on 05/10/16.
 */

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {

    Context context;
    private List<GetSaveLocationResponsePOJO.LocationsItem> LocatoinList;
    public RecyclerViewAdapter(Context context, List<GetSaveLocationResponsePOJO.LocationsItem> LocatoinList) {
    this.context = context;
    this.LocatoinList = LocatoinList;

    }



    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.place_recycler_item_layout, viewGroup, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter.MyViewHolder holder, int position) {

        holder.place_address.setText(LocatoinList.get(position).getFullAddress());

    }

    @Override
    public int getItemCount() {
        return LocatoinList.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {


        @BindView(R.id.place_address)
        TextView place_address;

        @BindView(R.id.place_area)
        TextView place_area;


        public MyViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);

        }
    }
}
