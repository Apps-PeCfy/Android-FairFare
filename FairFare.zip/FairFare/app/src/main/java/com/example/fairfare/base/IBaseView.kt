/*
 * Author : Chetan Patil.
 * Module : Base Module
 * Version : V 1.0
 * Sprint : III
 * Date of Development : 13/02/2019 9:15:00
 * Date of Modified : 13/02/2019 12:02:00
 * Comments : This is base view interface for all the view in mvp
 * Output : This is base view interface for all the view in mvp
 */
package com.example.fairfare.base

interface IBaseView {

    fun showWait()

    fun removeWait()

    fun onFailure(appErrorMessage: String?)

}
