package com.example.fairfare.ui.Login.pojo;

import com.google.gson.annotations.SerializedName;

public class LoginResponsepojo{

	@SerializedName("redirectTo")
	private String redirectTo;

	@SerializedName("token")
	private String token;

	@SerializedName("message")
	private String message;

	public void setRedirectTo(String redirectTo){
		this.redirectTo = redirectTo;
	}

	public String getRedirectTo(){
		return redirectTo;
	}

	public void setMessage(String message){
		this.message = message;
	}

	public String getMessage(){
		return message;
	}


public void setToken(String token){
		this.token = token;
	}

	public String getToken(){
		return token;
	}

	@Override
 	public String toString(){
		return 
			"LoginResponsepojo{" + 
			"redirectTo = '" + redirectTo + '\'' + 
			",message = '" + message + '\'' +
			",token = '" + token + '\'' +
			"}";
		}
}