package com.example.fairfare.utils;

public class Constants {

    public static String SHARED_PREFERENCE_LOGIN_TOKEN = "token";
    public static String SHARED_PREFERENCE_ISLOGIN = "isLogin";
}
