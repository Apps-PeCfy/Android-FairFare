package com.example.fairfare.ui.otp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.fairfare.R;
import com.example.fairfare.networking.ApiClient;
import com.example.fairfare.ui.Login.pojo.LoginResponsepojo;
import com.example.fairfare.ui.Login.pojo.ValidationResponse;
import com.example.fairfare.ui.home.HomeActivity;
import com.example.fairfare.ui.otp.pojo.VerifyOTPResponsePojo;
import com.example.fairfare.utils.Constants;
import com.example.fairfare.utils.PreferencesManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OtpAvtivity extends AppCompatActivity {
    String MobileNo, CountryCode, UserMail, Username, type, GoogleToken, LoginType;
    @BindView(R.id.otp)
    TextView otp;

    @BindView(R.id.edt_otp)
    EditText edt_otp;

    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    VerifyOTPResponsePojo verifyOTPResponsePojo;

    private PreferencesManager mPreferencesManager;

    @Override
    public void onBackPressed() {

        //super.onBackPressed();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_avtivity);
        ButterKnife.bind(this);
        PreferencesManager.initializeInstance(OtpAvtivity.this);
        mPreferencesManager = PreferencesManager.getInstance();
        setToolbar();
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            MobileNo = extras.getString("Mobile_No");
            CountryCode = extras.getString("CountryCode");
            UserMail = extras.getString("UserMail");
            Username = extras.getString("UserName");
            type = extras.getString("Activity");
            LoginType = extras.getString("LoginType");
            GoogleToken = extras.getString("GoogleToken");
            otp.setText("+" + CountryCode + " " + MobileNo);
        }
    }


    private void setToolbar() {
        setSupportActionBar(mToolbar);
        mToolbar.setNavigationOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onBackPressed();
                    }
                });
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
    }


    @OnClick(R.id.btnFinish)
    void btnLogin() {

        if (TextUtils.isEmpty(edt_otp.getText().toString()) || edt_otp.getTextSize() < 6) {
            Toast.makeText(this, "Please enter OTP", Toast.LENGTH_LONG).show();
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(OtpAvtivity.this);
            progressDialog.setCancelable(false); // set cancelable to false
            progressDialog.setMessage("Please Wait"); // set message
            progressDialog.show(); // show progress dialog

            if (LoginType.equals("NOR")) {
                GoogleToken = "";
            }

            (ApiClient.getClient().verifyOtp(MobileNo, type, "Android",
                    LoginType, CountryCode, Username, UserMail, "Male", edt_otp.getText().toString())).enqueue(new Callback<VerifyOTPResponsePojo>() {
                @Override
                public void onResponse(Call<VerifyOTPResponsePojo> call, Response<VerifyOTPResponsePojo> response) {
                    verifyOTPResponsePojo = response.body();
                    if (response.code() == 200) {

                        mPreferencesManager.setStringValue(Constants.SHARED_PREFERENCE_LOGIN_TOKEN, response.body().getToken());
                        mPreferencesManager.setStringValue(Constants.SHARED_PREFERENCE_ISLOGIN, "true");
                        edt_otp.setText("");
                        Intent intent = new Intent(OtpAvtivity.this, HomeActivity.class);
                        startActivity(intent);
                        finish();

                    } else {
                        Gson gson = new GsonBuilder().create();
                        ValidationResponse pojo = new ValidationResponse();

                        try {
                            pojo = gson.fromJson(response.errorBody().string(), ValidationResponse.class);

                            for (int i = 0; i < pojo.getErrors().size(); i++) {
                                if (pojo.getErrors().get(i).getKey().equals("otp")) {
                                    Toast.makeText(OtpAvtivity.this, pojo.getMessage(), Toast.LENGTH_SHORT).show();
                                    progressDialog.dismiss();
                                }
                            }


                        } catch (IOException exception) {
                        }

                    }


                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<VerifyOTPResponsePojo> call, Throwable t) {
                    Log.d("response", t.getStackTrace().toString());
                    progressDialog.dismiss();

                }
            });


        }
    }

    @OnClick(R.id.txt_resend_otp)
    void resendOTP() {
        edt_otp.setText("");
        final ProgressDialog progressDialog = new ProgressDialog(OtpAvtivity.this);
        progressDialog.setCancelable(false); // set cancelable to false
        progressDialog.setMessage("Please Wait"); // set message
        progressDialog.show(); // show progress dialog

        if (LoginType.equals("NOR")) {
            GoogleToken = "";
        }

        (ApiClient.getClient().login(MobileNo, type, "Android",
                LoginType, CountryCode, "", "", GoogleToken)).enqueue(new Callback<LoginResponsepojo>() {
            @Override
            public void onResponse(Call<LoginResponsepojo> call, Response<LoginResponsepojo> response) {

                if (response.code() == 200) {


                } else {


                }


                progressDialog.dismiss();
            }

            @Override
            public void onFailure(Call<LoginResponsepojo> call, Throwable t) {
                Log.d("response", t.getStackTrace().toString());
                progressDialog.dismiss();

            }
        });


    }
}
