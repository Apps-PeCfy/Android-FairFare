package com.example.fairfare.ui.Login;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.fairfare.R;
import com.example.fairfare.base.BaseLocationClass;
import com.example.fairfare.networking.ApiClient;
import com.example.fairfare.ui.Login.pojo.LoginResponsepojo;
import com.example.fairfare.ui.Login.pojo.ValidationResponse;
import com.example.fairfare.ui.Register.RegisterActivity;
import com.example.fairfare.ui.home.HomeActivity;
import com.example.fairfare.ui.otp.OtpAvtivity;
import com.example.fairfare.utils.Constants;
import com.example.fairfare.utils.PreferencesManager;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginBehavior;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.rilixtech.widget.countrycodepicker.Country;
import com.rilixtech.widget.countrycodepicker.CountryCodePicker;
import com.squareup.okhttp.FormEncodingBuilder;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.OnTextChanged;
import io.michaelrocks.libphonenumber.android.NumberParseException;
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil;
import io.michaelrocks.libphonenumber.android.Phonenumber;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends BaseLocationClass implements CountryCodePicker.OnCountryChangeListener {


    int facebookLoginClick = 0;
    String googleAccessTokem;
    @BindView(R.id.iv_gmail)
    ImageView iv_gmail;
    String countryCodeISO = "IN";
    String countryCode = "91";
    private CallbackManager callbackManager;
    @BindView(R.id.btnLogin)
    Button btnLogin;


    @BindView(R.id.tvPhoneNumberError)
    TextView tvPhoneNumberError;


    @BindView(R.id.edit_text)
    EditText edit_text;

    @BindView(R.id.ccpr)
    CountryCodePicker ccp;

    @BindView(R.id.btnLoginFacebook)
    Button btnLoginFacebook;

    @BindView(R.id.btnFBK)
    LoginButton btnFBK;

    LoginResponsepojo loginResponsepojo;
    private int SIGN_IN = 30;
    private GoogleSignInClient mGoogleSignInClient;
    private String gmailPersonName, gmailFirstName, gmailLastName, gmailPersonEmail, gToken, providerid;
    private String facebook_uid, fbFirstName, fbEmail, token;
    Country selectedCountryCode;

    private PreferencesManager mPreferencesManager;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
        // FacebookSdk.sdkInitialize(getApplicationContext());
        // hashkey();

        PreferencesManager.initializeInstance(LoginActivity.this);
        mPreferencesManager = PreferencesManager.getInstance();
        setStatusBarGradiant(this);
        FacebookSdk.sdkInitialize(LoginActivity.this);
        AppEventsLogger.activateApp(getApplication());


        callbackManager = CallbackManager.Factory.create();
        facebookLogin();
        ccp.setOnCountryChangeListener(this);

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken("254736596560-cnkg23q193qpnffh7u0mpcdbdmofua28.apps.googleusercontent.com")
                .requestServerAuthCode("254736596560-cnkg23q193qpnffh7u0mpcdbdmofua28.apps.googleusercontent.com")

                .requestId()
                .requestEmail()
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        //  ccp.registerPhoneNumberTextView(edit_text);

    }

    private void setStatusBarGradiant(LoginActivity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = activity.getWindow();
            Drawable background = activity.getResources().getDrawable(R.drawable.app_gradient);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(activity.getResources().getColor(android.R.color.transparent));
            window.setBackgroundDrawable(background);
        }
    }

    private void hashkey() {
        try {
            PackageInfo info = this.getPackageManager().getPackageInfo(this.getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String hashKey = new String(Base64.encode(md.digest(), 0));
                Log.i("printHashKey", "printHashKey() Hash Key: " + hashKey);
            }
        } catch (NoSuchAlgorithmException e) {
        } catch (Exception e) {
        }
    }


    @OnTextChanged(R.id.edit_text)
    void editPhone() {
        if (tvPhoneNumberError.getVisibility() == View.VISIBLE) {
            tvPhoneNumberError.setVisibility(View.GONE);
            return;
        }
    }


    @OnClick(R.id.iv_gmail)
    void gmail() {
        edit_text.setText("");
        ccp.setCountryForNameCode("in");
        signIn();


    }


    @OnTextChanged(R.id.edit_text)
    void edttxt() {

    }


    @OnClick(R.id.btnLoginFacebook)
    void onClickLoginWithFAcebook(View view) {
        edit_text.setText("");
        ccp.setCountryForNameCode("in");
        if (facebookLoginClick == 0) {
            facebookLoginClick = 1;
            btnFBK.performClick();
        }

    }


    @OnClick(R.id.btnFBK)
    void facebookButtonclick() {
        facebookLogin();
    }


    private void facebookLogin() {


        btnFBK.setReadPermissions(Arrays.asList("email", "public_profile"));
        btnFBK.setLoginBehavior(LoginBehavior.WEB_VIEW_ONLY);

        btnFBK.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {

                final GraphRequest request = GraphRequest.newMeRequest(AccessToken.getCurrentAccessToken(),
                        new GraphRequest.GraphJSONObjectCallback() {


                            @Override
                            public void onCompleted(JSONObject object, GraphResponse response) {
                                Log.i("LoginActivity", response.toString() + " * " + object.toString());
                                if (response.getError() == null) {
                                    try {


                                        facebook_uid = object.get("id").toString();
                                        fbFirstName = object.get("first_name").toString();
                                        fbEmail = object.get("email").toString();
                                        AccessToken accessToken = AccessToken.getCurrentAccessToken();
                                        token = accessToken.getToken();

                                        String profile_pic_url = object.getJSONObject("picture").getJSONObject("data").getString("url");

                                        if (AccessToken.getCurrentAccessToken() != null) {
                                            LoginManager.getInstance().logOut();
                                        }

                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }


                                final ProgressDialog progressDialog = new ProgressDialog(LoginActivity.this);
                                progressDialog.setCancelable(false); // set cancelable to false
                                progressDialog.setMessage("Please Wait"); // set message
                                progressDialog.show(); // show progress dialog
                                (ApiClient.getClient().sociallogin("Android", "FBK", fbFirstName,
                                        facebook_uid, token, fbEmail)).enqueue(new Callback<LoginResponsepojo>() {
                                    @Override
                                    public void onResponse(Call<LoginResponsepojo> call, Response<LoginResponsepojo> response) {
                                        loginResponsepojo = response.body();
                                        progressDialog.dismiss();

                                        if (response.code() == 200) {

                                            if (loginResponsepojo.getRedirectTo().equalsIgnoreCase("Register")) {
                                                Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
                                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                                intent.putExtra("Mobile_No", "");
                                                intent.putExtra("UserEmail", fbEmail);
                                                intent.putExtra("UserName", fbFirstName);
                                                intent.putExtra("CountryCode", countryCode);
                                                intent.putExtra("LoginType", "FBK");
                                                intent.putExtra("GoogleToken", token);
                                                intent.putExtra("countryCodeISO", countryCodeISO);


                                                startActivity(intent);
                                                finish();
                                            } else if (
                                                    loginResponsepojo.getRedirectTo().equalsIgnoreCase("home")) {
                                                assert response.body() != null;
                                                mPreferencesManager.setStringValue(Constants.SHARED_PREFERENCE_LOGIN_TOKEN, response.body().getToken());
                                                mPreferencesManager.setStringValue(Constants.SHARED_PREFERENCE_ISLOGIN, "true");
                                                Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                                                startActivity(intent);
                                                finish();

                                              //  Toast.makeText(LoginActivity.this, loginResponsepojo.getMessage(), Toast.LENGTH_LONG).show();

                                            }
                                        } else {


                                            Gson gson = new GsonBuilder().create();
                                            ValidationResponse pojo = new ValidationResponse();

                                            try {
                                                pojo = gson.fromJson(response.errorBody().string(), ValidationResponse.class);

                                                for (int i = 0; i < pojo.getErrors().size(); i++) {
                                                    Toast.makeText(LoginActivity.this, pojo.getErrors().get(0).getMessage(), Toast.LENGTH_LONG).show();

                                                }


                                            } catch (IOException exception) {
                                            }

                                        }


                                    }

                                    @Override
                                    public void onFailure(Call<LoginResponsepojo> call, Throwable t) {
                                        Log.d("response", t.getStackTrace().toString());
                                        progressDialog.dismiss();

                                    }
                                });


                            }
                        });
                Bundle parameters = new Bundle();
                parameters.putString("fields", "id, first_name,last_name, email,  picture.type(large)");
                request.setParameters(parameters);
                request.executeAsync();


            }

            @Override
            public void onCancel() {
            }

            @Override
            public void onError(FacebookException error) {
                error.printStackTrace();
            }
        });


    }


    @OnClick(R.id.tvSignUp)
    void tvSignUp() {
        Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("Mobile_No", "");
        intent.putExtra("UserEmail", "");
        intent.putExtra("CountryCode", "91");
        intent.putExtra("UserName", "");
        intent.putExtra("LoginType", "NOR");
        intent.putExtra("GoogleToken", "");
        intent.putExtra("countryCodeISO", "in");
        startActivity(intent);
        finish();
    }


    @OnClick(R.id.btnLogin)
    void callLogin() {
        PhoneNumberUtil phoneNumberUtil;
        Phonenumber.PhoneNumber phoneNumber = null;
        PhoneNumberUtil.PhoneNumberType isMobile = null;
        String strNumberValidation = "false";
        phoneNumberUtil = PhoneNumberUtil.createInstance(this);
        strNumberValidation = "";

        try {
            phoneNumber = phoneNumberUtil.parse(edit_text.getText().toString().trim(), countryCodeISO.toUpperCase());
            isMobile = phoneNumberUtil.getNumberType(phoneNumber);
        } catch (NumberParseException e) {
            e.printStackTrace();
        }


        if (PhoneNumberUtil.PhoneNumberType.MOBILE == isMobile) {
            strNumberValidation = "true";
        } else if (PhoneNumberUtil.PhoneNumberType.FIXED_LINE == isMobile) {
            strNumberValidation = "false";

        } else {
            strNumberValidation = "false";
        }


       /* try {

            phoneNumber = phoneNumberUtil.parse(edit_text.getText().toString(), countryCodeISO.toUpperCase());
            boolean isValid = phoneNumberUtil.isValidNumber(phoneNumber);

            strNumberValidation = String.valueOf(isValid);

        } catch (NumberParseException e) {
            e.printStackTrace();
        }*/


        if (strNumberValidation.equals("false")) {
            tvPhoneNumberError.setText("Please enter a valid phone no.");
            tvPhoneNumberError.setVisibility(View.VISIBLE);
            //   Toast.makeText(this, "Plese enter valid phone no.", Toast.LENGTH_LONG).show();
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(LoginActivity.this);
            progressDialog.setCancelable(false); // set cancelable to false
            progressDialog.setMessage("Please Wait"); // set message
            progressDialog.show(); // show progress dialog

            (ApiClient.getClient().login(edit_text.getText().toString(), "Login", "Android",
                    "NOR", countryCode, "", "", "")).enqueue(new Callback<LoginResponsepojo>() {
                @Override
                public void onResponse(Call<LoginResponsepojo> call, Response<LoginResponsepojo> response) {
                    loginResponsepojo = response.body();


                    if (loginResponsepojo.getRedirectTo().equals("Register")) {
                        Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.putExtra("Mobile_No", edit_text.getText().toString());
                        intent.putExtra("UserEmail", "");
                        intent.putExtra("CountryCode", countryCode);
                        intent.putExtra("UserName", "");
                        intent.putExtra("LoginType", "NOR");
                        intent.putExtra("GoogleToken", "");
                        intent.putExtra("countryCodeISO", countryCodeISO);
                        startActivity(intent);
                        finish();
                    } else {
                        Intent intent = new Intent(getApplicationContext(), OtpAvtivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.putExtra("Mobile_No", edit_text.getText().toString());
                        intent.putExtra("CountryCode", countryCode);
                        intent.putExtra("UserMail", "");
                        intent.putExtra("UserName", "");
                        intent.putExtra("Activity", "Login");
                        intent.putExtra("LoginType", "NOR");
                        intent.putExtra("GoogleToken", "");

                        startActivity(intent);
                        finish();

                    }


                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<LoginResponsepojo> call, Throwable t) {
                    Log.d("response", t.getStackTrace().toString());
                    progressDialog.dismiss();

                }
            });

        }
    }

    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, SIGN_IN);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                handleSignInResult(task);
            } catch (ApiException e) {
                e.printStackTrace();
            }
        } else {
            facebookLoginClick = 0;
            callbackManager.onActivityResult(requestCode, resultCode, data);
        }


    }


    private void handleSignInResult(Task<GoogleSignInAccount> task) throws ApiException {
        //   GoogleSignInAccount acctu = GoogleSignIn.getLastSignedInAccount(this);
        GoogleSignInAccount acct = task.getResult((ApiException.class));


        if (acct != null) {

            OkHttpClient client = new OkHttpClient();
            RequestBody requestBody = new FormEncodingBuilder()
                    .add("grant_type", "authorization_code")
                    .add("client_id", "254736596560-cnkg23q193qpnffh7u0mpcdbdmofua28.apps.googleusercontent.com")
                    .add("client_secret", "-ZAJiv8WoSGTb5pHPl_kdtSA")
                    .add("redirect_uri", "")
                    .add("code", acct.getServerAuthCode())
                    .build();


            Request request = new Request.Builder()
                    .url("https://www.googleapis.com/oauth2/v4/token")
                    .post(requestBody)
                    .build();
            client.newCall(request).enqueue(new com.squareup.okhttp.Callback() {
                @Override
                public void onFailure(Request request, IOException e) {

                }

                @Override
                public void onResponse(com.squareup.okhttp.Response response) throws IOException {
                    try {
                        JSONObject jsonObject = new JSONObject(response.body().string());
                        gToken = jsonObject.getString("access_token");


                        Log.d("access_token", gToken);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }


            });

            gmailPersonName = acct.getDisplayName();
            gmailFirstName = acct.getGivenName();
            gmailLastName = acct.getFamilyName();
            gmailPersonEmail = acct.getEmail();
            gToken = acct.getIdToken();//Token
            providerid = acct.getId();//proderid
            String auth = acct.getServerAuthCode();
            Uri personPhoto = acct.getPhotoUrl();

            Log.d("GmailData", auth);

            mGoogleSignInClient.signOut().addOnCompleteListener(this, new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {

                }
            });


        }
        if (!TextUtils.isEmpty(gToken)) {
            CallAPI();

        }

    }

    private void CallAPI() {


        final ProgressDialog progressDialoggmail = new ProgressDialog(LoginActivity.this);
        progressDialoggmail.setCancelable(false); // set cancelable to false
        progressDialoggmail.setMessage("Please Wait"); // set message
        progressDialoggmail.show(); // show progress dialog
        (ApiClient.getClient().sociallogin("Android", "GGL", gmailPersonName,
                providerid, gToken, gmailPersonEmail)).enqueue(new Callback<LoginResponsepojo>() {
            @Override
            public void onResponse(Call<LoginResponsepojo> call, Response<LoginResponsepojo> response) {
                loginResponsepojo = response.body();
                progressDialoggmail.dismiss();
                if (response.code() == 200) {

                    if (loginResponsepojo.getRedirectTo().equalsIgnoreCase("Register")) {
                        Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.putExtra("Mobile_No", "");
                        intent.putExtra("UserEmail", gmailPersonEmail);
                        intent.putExtra("UserName", gmailPersonName);
                        intent.putExtra("CountryCode", countryCode);
                        intent.putExtra("LoginType", "GGL");
                        intent.putExtra("GoogleToken", gToken);
                        intent.putExtra("countryCodeISO", countryCodeISO);


                        startActivity(intent);
                        finish();
                    } else if (loginResponsepojo.getRedirectTo().equalsIgnoreCase("home")) {

                        assert response.body() != null;
                        mPreferencesManager.setStringValue(Constants.SHARED_PREFERENCE_LOGIN_TOKEN, response.body().getToken());
                        mPreferencesManager.setStringValue(Constants.SHARED_PREFERENCE_ISLOGIN, "true");
                        Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                        startActivity(intent);
                        finish();

                      //  Toast.makeText(LoginActivity.this, loginResponsepojo.getMessage(), Toast.LENGTH_LONG).show();

                    }
                } else {


                    Gson gson = new GsonBuilder().create();
                    ValidationResponse pojo = new ValidationResponse();

                    try {
                        pojo = gson.fromJson(response.errorBody().string(), ValidationResponse.class);

                        for (int i = 0; i < pojo.getErrors().size(); i++) {
                            if (pojo.getErrors().get(i).getKey().equals("token")) {
                                CallAPIRepeate();
                                //progressDialog.dismiss();
                            } else {
                                progressDialoggmail.dismiss();
                                Toast.makeText(LoginActivity.this, pojo.getErrors().get(0).getMessage(), Toast.LENGTH_LONG).show();

                            }
                        }


                    } catch (IOException exception) {
                    }

                }


            }

            @Override
            public void onFailure(Call<LoginResponsepojo> call, Throwable t) {
                Log.d("response", t.getStackTrace().toString());
                // progressDialoggmail.dismiss();

            }
        });


    }

    private void CallAPIRepeate() {
        (ApiClient.getClient().sociallogin("Android", "GGL", gmailPersonName,
                providerid, gToken, gmailPersonEmail)).enqueue(new Callback<LoginResponsepojo>() {
            @Override
            public void onResponse(Call<LoginResponsepojo> call, Response<LoginResponsepojo> response) {
                loginResponsepojo = response.body();

                if (response.code() == 200) {
                    if (loginResponsepojo.getRedirectTo().equalsIgnoreCase("Register")) {
                        Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.putExtra("Mobile_No", "");
                        intent.putExtra("UserEmail", gmailPersonEmail);
                        intent.putExtra("UserName", gmailPersonName);
                        intent.putExtra("CountryCode", countryCode);
                        intent.putExtra("LoginType", "GGL");
                        intent.putExtra("GoogleToken", gToken);
                        intent.putExtra("countryCodeISO", countryCodeISO);


                        startActivity(intent);
                        finish();
                    } else if (loginResponsepojo.getRedirectTo().equalsIgnoreCase("home")) {

                        assert response.body() != null;
                        mPreferencesManager.setStringValue(Constants.SHARED_PREFERENCE_LOGIN_TOKEN, response.body().getToken());
                        mPreferencesManager.setStringValue(Constants.SHARED_PREFERENCE_ISLOGIN, "true");
                        Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                        startActivity(intent);
                        finish();

                       // Toast.makeText(LoginActivity.this, loginResponsepojo.getMessage(), Toast.LENGTH_LONG).show();

                    }
                } else {


                    Gson gson = new GsonBuilder().create();
                    ValidationResponse pojo = new ValidationResponse();

                    try {
                        pojo = gson.fromJson(response.errorBody().string(), ValidationResponse.class);

                        for (int i = 0; i < pojo.getErrors().size(); i++) {
                            if (pojo.getErrors().get(i).getKey().equals("token")) {
                                CallAPIRepeate();
                                //progressDialog.dismiss();
                            } else {
                                Toast.makeText(LoginActivity.this, pojo.getErrors().get(0).getMessage(), Toast.LENGTH_LONG).show();

                            }
                        }


                    } catch (IOException exception) {
                    }

                }


            }

            @Override
            public void onFailure(Call<LoginResponsepojo> call, Throwable t) {
                Log.d("response", t.getStackTrace().toString());
                // progressDialoggmail.dismiss();

            }
        });
    }


    @Override
    public void onCountrySelected(Country selectedCountry) {
        selectedCountryCode = selectedCountry;
        countryCode = selectedCountryCode.getPhoneCode();
        countryCodeISO = selectedCountryCode.getIso();
        // Toast.makeText(this, selectedCountry.getPhoneCode(), Toast.LENGTH_LONG).show();

    }


}
