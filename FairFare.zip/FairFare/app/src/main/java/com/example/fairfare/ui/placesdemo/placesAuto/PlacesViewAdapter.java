package com.example.fairfare.ui.placesdemo.placesAuto;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.fairfare.R;
import com.example.fairfare.ui.placesdemo.placesAuto.pojo.PredictionResponse;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PlacesViewAdapter extends RecyclerView.Adapter<PlacesViewAdapter.MyViewHolder> {

    PredictionResponse items;

    public PlacesViewAdapter(PredictionResponse items) {
        this.items = items;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View itemView = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.recycler_view_list_item, viewGroup, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull PlacesViewAdapter.MyViewHolder holder, int position) {

        holder.list_item.setText(items.getPredictions().get(position).getDescription());
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return 5;
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {




        @BindView(R.id.list_item)
        TextView list_item;



        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}

