package com.example.fairfare.ui.Login.pojo;

import com.google.gson.annotations.SerializedName;

public class ErrorsItem{

	@SerializedName("message")
	private String message;

	@SerializedName("key")
	private String key;

	public void setMessage(String message){
		this.message = message;
	}

	public String getMessage(){
		return message;
	}

	public void setKey(String key){
		this.key = key;
	}

	public String getKey(){
		return key;
	}

	@Override
 	public String toString(){
		return 
			"ErrorsItem{" + 
			"message = '" + message + '\'' + 
			",key = '" + key + '\'' + 
			"}";
		}
}