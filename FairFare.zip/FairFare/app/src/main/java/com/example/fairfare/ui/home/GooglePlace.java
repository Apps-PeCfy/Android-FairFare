package com.example.fairfare.ui.home;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.example.fairfare.R;
import com.google.android.gms.common.api.Status;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;

import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.List;

public class GooglePlace extends AppCompatActivity {
    private static int AUTOCOMPLETE_REQUEST_CODE = 1;
    EditText edit_txt;
    PlacesClient placesClient;
    AutocompleteSupportFragment autocompleteFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_place);
        edit_txt = (EditText) findViewById(R.id.edit_txt);

        String apiKey = "AIzaSyDTtO6dht-M6tX4uL28f8HTLwIQrT_ivUU";
        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), "AIzaSyDTtO6dht-M6tX4uL28f8HTLwIQrT_ivUU");
        }

        // Create a new Places client instance.
        placesClient = Places.createClient(this);


        edit_txt.setFocusable(false);
        edit_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Place.Field> fields = Arrays.asList(Place.Field.ID,
                        Place.Field.NAME,
                        Place.Field.LAT_LNG,
                        Place.Field.ADDRESS,
                        Place.Field.OPENING_HOURS);
                Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fields)
                        .build(GooglePlace.this);
                startActivityForResult(intent, AUTOCOMPLETE_REQUEST_CODE);
            }
        });



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == AUTOCOMPLETE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Place place = Autocomplete.getPlaceFromIntent(data);

                edit_txt.setText(place.getAddress());
                Log.i("PlaceData", "Place: " + place.getName() + ",      "
                        + place.getId()+"    "+place.getLatLng()+"   "
                        +place.getOpeningHours()+"    "+place.getAddress());
            } else if (resultCode == AutocompleteActivity.RESULT_ERROR) {
                // TODO: Handle the error.
                Status status = Autocomplete.getStatusFromIntent(data);
                Log.i("PlaceData", status.getStatusMessage());
            } else if (resultCode == RESULT_CANCELED) {
                // The user canceled the operation.
            }
            return;
        }

    }
}
