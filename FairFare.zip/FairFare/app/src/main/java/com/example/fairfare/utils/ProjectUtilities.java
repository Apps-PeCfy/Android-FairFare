package com.example.fairfare.utils;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.inputmethod.InputMethodManager;

import android.app.AlertDialog;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.PermissionChecker;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import com.example.fairfare.R;

public class ProjectUtilities {

    public static int location_fetch_time_interval = 1 * 60000;
    public static double latitude, longitude;
    public  static  boolean isPopUp = true;
    private  static ProgressDialog pDialog;

    public  static  int notificationcnt;
    public  static  double activity;

    // Define variable
    private static Boolean isInternetPresent = false;
    private static ConnectionDetector cd;
    private static String[] suffix = new String[]{"", "k", "m", "b", "t"};
    private static int MAX_LENGTH = 4;

    // This method is for checking internet connection
    public static Boolean checkInternetAvailable(Context mContext) {
        cd = new ConnectionDetector(mContext);
        isInternetPresent = cd.isConnectingToInternet();

        return isInternetPresent;

    }

    //This method hide keyboard
    public static void hideKeyboard(Activity mActivity) {
        try {
            InputMethodManager inputMethodManager = (InputMethodManager) mActivity
                    .getSystemService(Activity.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(mActivity
                    .getCurrentFocus().getWindowToken(), 0);

        } catch (Exception e) {

        }
    }

    //This method show progress dialog
    public static void showProgressDialog(Context mContext) {
        pDialog = new ProgressDialog(mContext);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        pDialog.show();
    }


    public static void showProgressBillingDialog(Context mContext) {
        pDialog = new ProgressDialog(mContext);
        pDialog.setMessage("It may take few minutes,your transaction is being processed...");
        pDialog.setCancelable(false);
        pDialog.show();
    }

    //This method dismiss progress dialog
    public static void dismissProgressDialog() {
        if (pDialog != null && pDialog.isShowing())
            pDialog.dismiss();
    }

    //this method show internet diaolg
    public static void internetDialog(Context mContext) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(mContext);

        alertDialog.setTitle(mContext.getResources()
                .getString(R.string.warning));
        alertDialog.setMessage(mContext.getResources().getString(
                R.string.internet_error));
        alertDialog.setCancelable(false);
        alertDialog.setPositiveButton(
                mContext.getResources().getString(R.string.btn_ok),
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // TODO Auto-generated method stub

                        dialog.cancel();
                    }
                });
        alertDialog.show();
    }

    public static void showAlertDialog(Context mContext, String message) {

        if (mContext != null) {

            AlertDialog.Builder alertDialog = new AlertDialog.Builder(mContext);
            alertDialog.setCancelable(false);
            alertDialog.setTitle(mContext.getString(R.string.app_name));
            alertDialog.setMessage(message);

            alertDialog.setPositiveButton(
                    mContext.getResources().getString(R.string.btn_ok),
                    new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub

                            dialog.cancel();
                        }
                    });
            alertDialog.show();


        }
    }

    public static void showAlertDialog(Context mContext, String title, String message) {

        if (mContext != null) {

            AlertDialog.Builder alertDialog = new AlertDialog.Builder(mContext);
            alertDialog.setCancelable(false);

            alertDialog.setTitle(title);
            alertDialog.setMessage(message);

            alertDialog.setPositiveButton(
                    mContext.getResources().getString(R.string.btn_ok),
                    new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub

                            dialog.cancel();
                        }
                    });
            alertDialog.show();
        }
    }

    public static void showToast(Context mContext, String message) {
        Toast.makeText(mContext, "" + message, Toast.LENGTH_LONG).show();
    }

    public static boolean checkPermission(Context mContext) {
        String[] PERMISSIONS = new String[]{
                Manifest.permission.CAMERA,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.ACCESS_FINE_LOCATION
        };

        int size = 0;
        for (int i = 0; i < PERMISSIONS.length; i++) {
            if (PermissionChecker.PERMISSION_GRANTED == ActivityCompat.checkSelfPermission(mContext, PERMISSIONS[i])) {
                size++;
            }
        }

        return size == PERMISSIONS.length;
    }

    /*
     * This method is used for runtime permission and make a call
     */
    @SuppressLint("MissingPermission")
    public static void makeCall(Context mContext, String phoneNumber) {
        mContext.startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + phoneNumber)));
    }

    /*
     * This method is used for web browser
     */
    public static void openUrlToWebView(Context mContext, String url) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        mContext.startActivity(browserIntent);
    }

    public static String formatNumber(double number) {
       /* String r = new DecimalFormat("##0E0").format(number);
        r = r.replaceAll("E[0-9]", suffix[Character.getNumericValue(r.charAt(r.length() - 1)) / 3]);
        while (r.length() > MAX_LENGTH || r.matches("[0-9]+\\.[a-z]")) {
            r = r.substring(0, r.length() - 2) + r.substring(r.length() - 1);
        }
        return r;*/
        int power;
        String suffix = " kmbt";
        String formattedNumber = "";

        NumberFormat formatter = new DecimalFormat("#,###.#");
        power = (int)StrictMath.log10(number);
        number = number/(Math.pow(10,(power/3)*3));
        formattedNumber=formatter.format(number);
        formattedNumber = formattedNumber + suffix.charAt(power/3);
        return formattedNumber.length()>4 ?  formattedNumber.replaceAll("\\.[0-9]+", "") : formattedNumber;
    }





}
