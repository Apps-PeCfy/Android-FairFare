package com.example.fairfare.ui.home.pojo;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetSaveLocationResponsePOJO{

	@SerializedName("data")
	private Data data;

	@SerializedName("message")
	private String message;

	public void setData(Data data){
		this.data = data;
	}

	public Data getData(){
		return data;
	}

	public void setMessage(String message){
		this.message = message;
	}

	public String getMessage(){
		return message;
	}

	@Override
 	public String toString(){
		return 
			"GetSaveLocationResponsePOJO{" + 
			"data = '" + data + '\'' + 
			",message = '" + message + '\'' + 
			"}";
		}






	public class Data{

		@SerializedName("first_page_url")
		private String firstPageUrl;

		@SerializedName("path")
		private String path;

		@SerializedName("per_page")
		private int perPage;

		@SerializedName("total")
		private int total;

		@SerializedName("last_page")
		private int lastPage;

		@SerializedName("last_page_url")
		private String lastPageUrl;

		@SerializedName("next_page_url")
		private String nextPageUrl;

		@SerializedName("locations")
		private List<LocationsItem> locations;

		@SerializedName("prev_page_url")
		private String prevPageUrl;

		@SerializedName("current_page")
		private int currentPage;

		public void setFirstPageUrl(String firstPageUrl){
			this.firstPageUrl = firstPageUrl;
		}

		public String getFirstPageUrl(){
			return firstPageUrl;
		}

		public void setPath(String path){
			this.path = path;
		}

		public String getPath(){
			return path;
		}

		public void setPerPage(int perPage){
			this.perPage = perPage;
		}

		public int getPerPage(){
			return perPage;
		}

		public void setTotal(int total){
			this.total = total;
		}

		public int getTotal(){
			return total;
		}

		public void setLastPage(int lastPage){
			this.lastPage = lastPage;
		}

		public int getLastPage(){
			return lastPage;
		}

		public void setLastPageUrl(String lastPageUrl){
			this.lastPageUrl = lastPageUrl;
		}

		public String getLastPageUrl(){
			return lastPageUrl;
		}

		public void setNextPageUrl(String nextPageUrl){
			this.nextPageUrl = nextPageUrl;
		}

		public String getNextPageUrl(){
			return nextPageUrl;
		}

		public void setLocations(List<LocationsItem> locations){
			this.locations = locations;
		}

		public List<LocationsItem> getLocations(){
			return locations;
		}

		public void setPrevPageUrl(String prevPageUrl){
			this.prevPageUrl = prevPageUrl;
		}

		public String getPrevPageUrl(){
			return prevPageUrl;
		}

		public void setCurrentPage(int currentPage){
			this.currentPage = currentPage;
		}

		public int getCurrentPage(){
			return currentPage;
		}

		@Override
		public String toString(){
			return
					"Data{" +
							"first_page_url = '" + firstPageUrl + '\'' +
							",path = '" + path + '\'' +
							",per_page = '" + perPage + '\'' +
							",total = '" + total + '\'' +
							",last_page = '" + lastPage + '\'' +
							",last_page_url = '" + lastPageUrl + '\'' +
							",next_page_url = '" + nextPageUrl + '\'' +
							",locations = '" + locations + '\'' +
							",prev_page_url = '" + prevPageUrl + '\'' +
							",current_page = '" + currentPage + '\'' +
							"}";
		}
	}













	public class LocationsItem{

		@SerializedName("country")
		private String country;

		@SerializedName("user_id")
		private int userId;

		@SerializedName("city")
		private String city;

		@SerializedName("id")
		private int id;

		@SerializedName("state")
		private String state;

		@SerializedName("full_address")
		private String fullAddress;

		@SerializedName("place_id")
		private String placeId;

		public void setCountry(String country){
			this.country = country;
		}

		public String getCountry(){
			return country;
		}

		public void setUserId(int userId){
			this.userId = userId;
		}

		public int getUserId(){
			return userId;
		}

		public void setCity(String city){
			this.city = city;
		}

		public String getCity(){
			return city;
		}

		public void setId(int id){
			this.id = id;
		}

		public int getId(){
			return id;
		}

		public void setState(String state){
			this.state = state;
		}

		public String getState(){
			return state;
		}

		public void setFullAddress(String fullAddress){
			this.fullAddress = fullAddress;
		}

		public String getFullAddress(){
			return fullAddress;
		}

		public void setPlaceId(String placeId){
			this.placeId = placeId;
		}

		public String getPlaceId(){
			return placeId;
		}

		@Override
		public String toString(){
			return
					"LocationsItem{" +
							"country = '" + country + '\'' +
							",user_id = '" + userId + '\'' +
							",city = '" + city + '\'' +
							",id = '" + id + '\'' +
							",state = '" + state + '\'' +
							",full_address = '" + fullAddress + '\'' +
							",place_id = '" + placeId + '\'' +
							"}";
		}
	}
}