package com.example.fairfare.ui.splashscreen;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.fairfare.R;
import com.example.fairfare.ui.Login.LoginActivity;
import com.example.fairfare.ui.home.HomeActivity;
import com.example.fairfare.utils.Constants;
import com.example.fairfare.utils.PreferencesManager;

public class SplashScreen extends AppCompatActivity {

    private static int REQUEST_PERMISSION = 100;
    String isLogin;
    PreferencesManager mPreferencesManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        PreferencesManager.initializeInstance(SplashScreen.this);
        mPreferencesManager = PreferencesManager.getInstance();

        isLogin = mPreferencesManager.getStringValue(Constants.SHARED_PREFERENCE_ISLOGIN);

        Handler h = new Handler();
        h.postDelayed(new Runnable() {
            public void run() {

                ActivityCompat.requestPermissions(SplashScreen.this,
                        new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION},
                        REQUEST_PERMISSION);

            }
        }, 2000 * 1);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {

        if (requestCode == REQUEST_PERMISSION) {


            if (isLogin.equals("true")) {
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(intent);
                finish();

            }else {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                finish();
            }



        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}
