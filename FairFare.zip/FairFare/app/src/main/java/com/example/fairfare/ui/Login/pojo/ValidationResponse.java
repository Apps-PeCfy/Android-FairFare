package com.example.fairfare.ui.Login.pojo;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class ValidationResponse{

	@SerializedName("message")
	private String message;

	@SerializedName("errors")
	private List<ErrorsItem> errors;

	public void setMessage(String message){
		this.message = message;
	}

	public String getMessage(){
		return message;
	}

	public void setErrors(List<ErrorsItem> errors){
		this.errors = errors;
	}

	public List<ErrorsItem> getErrors(){
		return errors;
	}

	@Override
 	public String toString(){
		return 
			"ValidationResponse{" + 
			"message = '" + message + '\'' + 
			",errors = '" + errors + '\'' + 
			"}";
		}
}