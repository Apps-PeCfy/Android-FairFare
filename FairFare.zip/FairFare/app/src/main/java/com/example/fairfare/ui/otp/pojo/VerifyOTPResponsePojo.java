package com.example.fairfare.ui.otp.pojo;

import com.google.gson.annotations.SerializedName;

public class VerifyOTPResponsePojo{

	@SerializedName("message")
	private String message;

	@SerializedName("user")
	private User user;

	@SerializedName("token")
	private String token;

	public void setMessage(String message){
		this.message = message;
	}

	public String getMessage(){
		return message;
	}

	public void setUser(User user){
		this.user = user;
	}

	public User getUser(){
		return user;
	}

	public void setToken(String token){
		this.token = token;
	}

	public String getToken(){
		return token;
	}

	@Override
	public String toString(){
		return
				"VResponse{" +
						"message = '" + message + '\'' +
						",user = '" + user + '\'' +
						",token = '" + token + '\'' +
						"}";
	}


	public class User{

		@SerializedName("phone_no")
		private String phoneNo;

		@SerializedName("gender")
		private String gender;

		@SerializedName("country_phone_code")
		private String countryPhoneCode;

		@SerializedName("name")
		private String name;

		@SerializedName("id")
		private int id;

		@SerializedName("email")
		private String email;

		public void setPhoneNo(String phoneNo){
			this.phoneNo = phoneNo;
		}

		public String getPhoneNo(){
			return phoneNo;
		}

		public void setGender(String gender){
			this.gender = gender;
		}

		public String getGender(){
			return gender;
		}

		public void setCountryPhoneCode(String countryPhoneCode){
			this.countryPhoneCode = countryPhoneCode;
		}

		public String getCountryPhoneCode(){
			return countryPhoneCode;
		}

		public void setName(String name){
			this.name = name;
		}

		public String getName(){
			return name;
		}

		public void setId(int id){
			this.id = id;
		}

		public int getId(){
			return id;
		}

		public void setEmail(String email){
			this.email = email;
		}

		public String getEmail(){
			return email;
		}

		@Override
		public String toString(){
			return
					"User{" +
							"phone_no = '" + phoneNo + '\'' +
							",gender = '" + gender + '\'' +
							",country_phone_code = '" + countryPhoneCode + '\'' +
							",name = '" + name + '\'' +
							",id = '" + id + '\'' +
							",email = '" + email + '\'' +
							"}";
		}
	}
}