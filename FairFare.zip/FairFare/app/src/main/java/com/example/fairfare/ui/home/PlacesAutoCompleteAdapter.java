package com.example.fairfare.ui.home;

import android.content.Context;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.text.style.CharacterStyle;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fairfare.R;
import com.example.fairfare.networking.ApiClient;
import com.example.fairfare.ui.home.pojo.SaveLocationResponsePojo;
import com.example.fairfare.ui.otp.OtpAvtivity;
import com.example.fairfare.utils.Constants;
import com.example.fairfare.utils.PreferencesManager;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.android.libraries.places.api.model.AutocompletePrediction;
import com.google.android.libraries.places.api.model.AutocompleteSessionToken;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.FetchPlaceRequest;
import com.google.android.libraries.places.api.net.FetchPlaceResponse;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsResponse;
import com.google.android.libraries.places.api.net.PlacesClient;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class PlacesAutoCompleteAdapter extends RecyclerView.Adapter<PlacesAutoCompleteAdapter.PredictionHolder> implements Filterable {
    private static final String TAG = "PlacesAutoAdapter";
    private ArrayList<PlaceAutocomplete> mResultList = new ArrayList<>();

    String token;
    PreferencesManager preferencesManager;
    private Context mContext;
    private CharacterStyle STYLE_BOLD;
    private CharacterStyle STYLE_NORMAL;
    private final PlacesClient placesClient;
    private ClickListener clickListener;

    public PlacesAutoCompleteAdapter(Context context) {

        mContext = context;
        STYLE_BOLD = new StyleSpan(Typeface.BOLD);
        STYLE_NORMAL = new StyleSpan(Typeface.NORMAL);
        placesClient = com.google.android.libraries.places.api.Places.createClient(context);
        PreferencesManager.initializeInstance(mContext);
        preferencesManager = PreferencesManager.getInstance();
    }

    public void setClickListener(ClickListener clickListener) {
        this.clickListener = clickListener;
    }

    public interface ClickListener {
        void click(Place place);


        void favClick(Place place);

    }

    /**
     * Returns the filter for the current set of autocomplete results.
     */
    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults results = new FilterResults();
                // Skip the autocomplete query if no constraints are given.
                if (constraint != null) {
                    // Query the autocomplete API for the (constraint) search string.
                    mResultList = getPredictions(constraint);
                    if (mResultList != null) {
                        // The API successfully returned results.
                        results.values = mResultList;
                        results.count = mResultList.size();
                    }
                }
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                if (results != null && results.count > 0) {
                    // The API returned at least one result, update the data.
                    notifyDataSetChanged();
                } else {
                    // The API did not return any results, invalidate the data set.
                    //notifyDataSetInvalidated();
                }
            }
        };
    }


    private ArrayList<PlaceAutocomplete> getPredictions(CharSequence constraint) {

        final ArrayList<PlaceAutocomplete> resultList = new ArrayList<>();

        // Create a new token for the autocomplete session. Pass this to FindAutocompletePredictionsRequest,
        // and once again when the user makes a selection (for example when calling fetchPlace()).
        AutocompleteSessionToken token = AutocompleteSessionToken.newInstance();

        //https://gist.github.com/graydon/11198540
        // Use the builder to create a FindAutocompletePredictionsRequest.
        FindAutocompletePredictionsRequest request = FindAutocompletePredictionsRequest.builder()
                // Call either setLocationBias() OR setLocationRestriction().
                //.setLocationBias(bounds)
                //.setCountry("BD")
                //.setTypeFilter(TypeFilter.ADDRESS)
                .setSessionToken(token)
                .setQuery(constraint.toString())
                .build();

        Task<FindAutocompletePredictionsResponse> autocompletePredictions = placesClient.findAutocompletePredictions(request);

        // This method should have been called off the main UI thread. Block and wait for at most
        // 60s for a result from the API.
        try {
            Tasks.await(autocompletePredictions, 60, TimeUnit.SECONDS);
        } catch (ExecutionException | InterruptedException | TimeoutException e) {
            e.printStackTrace();
        }

        if (autocompletePredictions.isSuccessful()) {
            FindAutocompletePredictionsResponse findAutocompletePredictionsResponse = autocompletePredictions.getResult();
            if (findAutocompletePredictionsResponse != null)
                for (AutocompletePrediction prediction : findAutocompletePredictionsResponse.getAutocompletePredictions()) {
                    Log.i(TAG, prediction.getPlaceId());
                    resultList.add(new PlaceAutocomplete(prediction.getPlaceId(),
                            prediction.getPrimaryText(STYLE_NORMAL).toString(), prediction.getFullText(STYLE_BOLD).toString()));
                }

            return resultList;
        } else {
            return resultList;
        }

    }

    @NonNull
    @Override
    public PredictionHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View convertView = layoutInflater.inflate(R.layout.place_recycler_item_layout, viewGroup, false);
        return new PredictionHolder(convertView);
    }

    @Override
    public void onBindViewHolder(@NonNull PredictionHolder mPredictionHolder, final int i) {
        mPredictionHolder.address.setText(mResultList.get(i).address);
        mPredictionHolder.area.setText(mResultList.get(i).area);
    }

    @Override
    public int getItemCount() {
        return mResultList.size();
    }

    public PlaceAutocomplete getItem(int position) {
        return mResultList.get(position);
    }

    public class PredictionHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView address, area;
        private RelativeLayout mRoW;
        private ImageView iv_fav;

        PredictionHolder(View itemView) {
            super(itemView);
            area = itemView.findViewById(R.id.place_area);
            address = itemView.findViewById(R.id.place_address);
            mRoW = itemView.findViewById(R.id.place_item);
            iv_fav = itemView.findViewById(R.id.iv_fav);
            itemView.setOnClickListener(this);
            iv_fav.setOnClickListener(this);
            mRoW.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            PlaceAutocomplete item = mResultList.get(getAdapterPosition());
            if (v.getId() == R.id.place_item) {

                String placeId = String.valueOf(item.placeId);

                List<Place.Field> placeFields = Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG, Place.Field.ADDRESS);
                FetchPlaceRequest request = FetchPlaceRequest.builder(placeId, placeFields).build();
                placesClient.fetchPlace(request).addOnSuccessListener(new OnSuccessListener<FetchPlaceResponse>() {
                    @Override
                    public void onSuccess(FetchPlaceResponse response) {
                        Place place = response.getPlace();
                        clickListener.click(place);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        if (exception instanceof ApiException) {
                            Toast.makeText(mContext, exception.getMessage() + "", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }


            if (v.getId() == R.id.iv_fav) {


                String placeId = String.valueOf(item.placeId);

                List<Place.Field> placeFields = Arrays.asList(Place.Field.ID, Place.Field.NAME,
                        Place.Field.LAT_LNG, Place.Field.ADDRESS);
                FetchPlaceRequest request = FetchPlaceRequest.builder(placeId, placeFields).build();
                placesClient.fetchPlace(request).addOnSuccessListener(new OnSuccessListener<FetchPlaceResponse>() {
                    @Override
                    public void onSuccess(FetchPlaceResponse response) {
                        Address returnedAddress = null;
                        Place place = response.getPlace();
                        //   clickListener.favClick(place);

                        Geocoder geocoder = new Geocoder(mContext, Locale.getDefault());
                        try {
                            List<Address> addresses = geocoder.getFromLocation(place.getLatLng().latitude,
                                    place.getLatLng().longitude, 1);
                            if (addresses != null) {
                                returnedAddress = addresses.get(0);


                            }
                        } catch (IOException e) {
                        }
                        // String sds = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiMDEwZjBlY2JjMmIwOTNmN2Q4NWI4ZmFmNzNiODY4YTAwNjdiOTJmYzRkNWQ4MmEyMWQ0MDVmNTk0Yjc4NThlM2EwZGVmYWZjYjljYmNmOTkiLCJpYXQiOjE2MDIxNjU2MDgsIm5iZiI6MTYwMjE2NTYwOCwiZXhwIjoxNjMzNzAxNjA4LCJzdWIiOiIxNSIsInNjb3BlcyI6W119.aFkHnjcx9gcpheTfhiPhDOgp9_bm63ZX_2_T6VVlhbavsRarDmx9tjz0PXQX54EonDYyZ8MHbAq-FHM7wBAj5qBuuzHRKIr2ofw-rxC0Q_wRouxNckT0b3Jja1FzozYYNzOn740xLA19YNnUmsZoyl0ELs0ZNjs401_KBL3TYUe3rqZVFCZqqUqxkaUGKVAn25TIp71kG7R0rPaqZCQd9_1UiKJctoOy2Cxhmlfy6s1ihAL4PhLz9bZ90jDPGAPFhC47vNM83hY0U-DydApeGN3xBT0QATe7z6sX7DlnWSB35x3EE9ySIXT-3l0o0COQOzr7hol0fhVpBEf0oYcwbiMQyQl3Ak4Aixa217D2mPsDupK0bMAiTIRPC8qE63yXI2u3vFA57be5OR6JV_-3PxdmIJ8mpHBQpgWjY9H7_EG36s2QvYoArrquFDtIduff0K_MSkM_qju0Zt7x4B6ulliDYnKE0T0xR77_31MHZK9QpdW3cWmxDORg9sdSi9c6GxHrR-f7SbJmWcTLaxeM1p5PTGjAfzeHqU3CYId8vV9MoEYraePrzLywSpHVNJhk68gu490PIPH-xy-GhwulKeNbpEMlfYiTSzAqGSjl3cPDWcNZCWoJKPMG4s6KQ-4X6Ijcczq8Pxsdz4EWPRax_AC0vf0-egGXEFboBqjKol8";
                        String token = preferencesManager.getStringValue(Constants.SHARED_PREFERENCE_LOGIN_TOKEN);

                        (ApiClient.getClient().SaveLocation("Bearer " + token, place.getId(), returnedAddress.getSubAdminArea(),
                                returnedAddress.getAdminArea(),
                                returnedAddress.getCountryName(),
                                place.getAddress())).enqueue(new Callback<SaveLocationResponsePojo>() {
                            @Override
                            public void onResponse(Call<SaveLocationResponsePojo> call, Response<SaveLocationResponsePojo> response) {
                                iv_fav.setBackgroundResource(R.drawable.ic_fav_checked);
                                Toast.makeText(mContext, response.body().getMessage(), Toast.LENGTH_SHORT).show();


                            }

                            @Override
                            public void onFailure(Call<SaveLocationResponsePojo> call, Throwable t) {
                                Log.d("response", t.getStackTrace().toString());

                            }
                        });


                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        if (exception instanceof ApiException) {
                            Toast.makeText(mContext, exception.getMessage() + "", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        }
    }

    /**
     * Holder for Places Geo Data Autocomplete API results.
     */
    public class PlaceAutocomplete {

        public CharSequence placeId;
        public CharSequence address, area;

        PlaceAutocomplete(CharSequence placeId, CharSequence area, CharSequence address) {
            this.placeId = placeId;
            this.area = area;
            this.address = address;
        }

        @Override
        public String toString() {
            return area.toString();
        }
    }
}
