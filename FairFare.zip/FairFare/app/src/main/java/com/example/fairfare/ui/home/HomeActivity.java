package com.example.fairfare.ui.home;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.icu.util.Calendar;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.fairfare.R;
import com.example.fairfare.ui.Register.RegisterActivity;
import com.example.fairfare.ui.placesdemo.mapTab.DirectionsJSONParser;
import com.example.fairfare.ui.placesdemo.mapTab.MapTab;
import com.example.fairfare.ui.placesdemo.placesAuto.PlacesDemo;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.material.tabs.TabLayout;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static android.view.Gravity.START;

public class HomeActivity extends FragmentActivity implements OnMapReadyCallback, DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener {

    LocationManager locationManager;
    double currentLatitude;
    double currentLongitude;
    private Polyline mPolyline;


    String[] timeSpinner = {"Now", "Later"};
    String[] luggageSpinner = {"1 Bag", "2 Bags", "3 Bags", "4 Bags", "5 Bags", "6 Bags", "7 Bags", "8 Bags",
            "9 Bags", "10 Bags"};

    @BindView(R.id.drawer_layout)
    DrawerLayout mDrawerLayout;


    @BindView(R.id.btnCompareRide)
    Button btnCompareRide;

    @BindView(R.id.add)
    Button add;

    @BindView(R.id.rlRideScheduled)
    RelativeLayout rlRideScheduled;

    @BindView(R.id.reestimateDateandTime)
    RelativeLayout reestimateDateandTime;

    @BindView(R.id.spinner_time)
    Spinner spinner_time;

    @BindView(R.id.spinner_Luggage)
    Spinner spinner_Luggage;

    @BindView(R.id.toolbar_home)
    Toolbar toolbar;

    @BindView(R.id.tv_myDropUpLocation)
    TextView myDropUpLocation;

    @BindView(R.id.tv_RideScheduled)
    TextView tv_RideScheduled;

    @BindView(R.id.tv_myCurrentLocation)
    TextView myCurrentLocation;

    @BindView(R.id.tvEstTime)
    TextView tvEstTime;

    @BindView(R.id.tvEstDistance)
    TextView tvEstDistance;


    private ActionBarDrawerToggle drawerToggle;
    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;


    private GoogleMap mMap;
    Bundle extras;
    String streetAddress = null;
    SharedPreferences sharedpreferences;

    String SourceLat, SourceLong, DestinationLat, DestinationLong;
    int day, month, year, hour, minute, AMorPM;
    int myday, myMonth, myYear, myHour, myMinute;
    Calendar calendar;

    String estTime, estDistance;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        ButterKnife.bind(this);
        setStatusBarGradiant(this);
        sharedpreferences = getSharedPreferences("mypref", Context.MODE_PRIVATE);
        Intent intent = getIntent();
        extras = intent.getExtras();
        rlRideScheduled.setVisibility(View.GONE);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
      /*  if (ActivityCompat.checkSelfPermission(HomeActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(HomeActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {*/
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        Location locationGPS = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (locationGPS != null) {
                currentLatitude = locationGPS.getLatitude();
                currentLongitude = locationGPS.getLongitude();


            } else {
                Toast.makeText(this, "Unable to find location.", Toast.LENGTH_SHORT).show();
            }


        getcurrentDate();
        initView();
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        ArrayAdapter NowLater = new ArrayAdapter(this, android.R.layout.simple_spinner_item, timeSpinner);
        NowLater.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_time.setAdapter(NowLater);


        spinner_time.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String spinnertxt = spinner_time.getSelectedItem().toString();

                if (spinnertxt.equals("Later")) {
                    rlRideScheduled.setVisibility(View.VISIBLE);
                } else {
                    rlRideScheduled.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        ArrayAdapter spinnerLuggage = new ArrayAdapter(this, android.R.layout.simple_spinner_item, luggageSpinner);
        spinnerLuggage.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_Luggage.setAdapter(spinnerLuggage);

    }

    private void getcurrentDate() {
        Date today = new Date();
        SimpleDateFormat format = new SimpleDateFormat("dd MMM, hh:mm a");
        String dateToStr = format.format(today);

        tv_RideScheduled.setText(dateToStr);
    }

    private void initView() {
        toolbar.setTitle("");
        toolbar.setTitleTextColor(getResources().getColor(android.R.color.white));

        drawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar,
                R.string.drawer_open, R.string.drawer_close) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }
        };


        mDrawerLayout.addDrawerListener(drawerToggle);
        drawerToggle.setDrawerIndicatorEnabled(true);
        drawerToggle.setDrawerIndicatorEnabled(false);
        drawerToggle.setHomeAsUpIndicator(R.drawable.ic_action_menu);
        drawerToggle.syncState();
        drawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View view) {
                if (mDrawerLayout.isDrawerOpen(START)) {
                    mDrawerLayout.closeDrawer(START);
                } else {
                    mDrawerLayout.openDrawer(START);

                }
            }
        });


    }

    @OnClick(R.id.tv_RideScheduled)
    void RideScheduled() {
        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(HomeActivity.this,
                HomeActivity.this, year, month, day);
        datePickerDialog.getDatePicker().setMinDate(new Date().getTime());
        datePickerDialog.show();

    }

    @OnClick(R.id.tv_myCurrentLocation)
    void myCurrentLocation() {
        Intent intent = new Intent(getApplicationContext(), PickUpDropActivity.class);
        if (SourceLat.isEmpty()) {

            intent.putExtra("Toolbar_Title", "Pick-Up");
            intent.putExtra("currentLatitude", currentLatitude);
            intent.putExtra("currentLongitude", currentLongitude);
        } else {
            intent.putExtra("Toolbar_Title", "Pick-Up");
            intent.putExtra("currentLatitude", Double.parseDouble(SourceLat));
            intent.putExtra("currentLongitude", Double.parseDouble(SourceLong));
        }

        startActivity(intent);
    }


    @Override
    protected void onDestroy() {
        sharedpreferences.edit().clear().commit();
        super.onDestroy();
    }

    @OnClick(R.id.tv_myDropUpLocation)
    void myDropUpLocation() {
        Intent intent = new Intent(getApplicationContext(), PickUpDropActivity.class);
        if (DestinationLat.isEmpty()) {
            intent.putExtra("Toolbar_Title", "Drop-off");
            intent.putExtra("currentLatitude", currentLatitude);
            intent.putExtra("currentLongitude", currentLongitude);
        } else {
            intent.putExtra("Toolbar_Title", "Drop-off");
            intent.putExtra("currentLatitude", Double.parseDouble(DestinationLat));
            intent.putExtra("currentLongitude", Double.parseDouble(DestinationLong));
        }


        startActivity(intent);
    }


    private void setStatusBarGradiant(HomeActivity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = activity.getWindow();
            Drawable background = activity.getResources().getDrawable(R.drawable.app_gradient);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(activity.getResources().getColor(android.R.color.transparent));
            window.setBackgroundDrawable(background);
        }
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        SourceLat = sharedpreferences.getString("SourceLat", "");
        SourceLong = sharedpreferences.getString("SourceLong", "");
        DestinationLat = sharedpreferences.getString("DestinationLat", "");
        DestinationLong = sharedpreferences.getString("DestinationLong", "");
        Log.d("mMarkerPointsSize", SourceLat + "       " + SourceLong);
        Log.d("mMarkerPointsSizeDestin", DestinationLat + "    " + DestinationLong);


        if (extras != null) {
            if (!SourceLat.isEmpty()) {
                Geocoder geocoderSource = new Geocoder(HomeActivity.this, Locale.getDefault());
                try {
                    List<Address> addresses = geocoderSource.getFromLocation(Double.parseDouble(SourceLat),
                            Double.parseDouble(SourceLong), 1);
                    if (addresses != null) {
                        Address returnedAddress = addresses.get(0);
                        StringBuilder strReturnedAddress = new StringBuilder();
                        for (int j = 0; j <= returnedAddress.getMaxAddressLineIndex(); j++) {
                            strReturnedAddress.append(returnedAddress.getAddressLine(j));
                        }
                        streetAddress = strReturnedAddress.toString();
                    }
                } catch (IOException e) {
                }

                myCurrentLocation.setText(streetAddress);

                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(Double.parseDouble(SourceLat), Double.parseDouble(SourceLong)), 13.0f));

                mMap.addMarker(new MarkerOptions().position(new LatLng(Double.parseDouble(SourceLat),
                        Double.parseDouble(SourceLong))));
            }

            if (!DestinationLat.isEmpty()) {
                Geocoder geocoderDestination = new Geocoder(HomeActivity.this,
                        Locale.getDefault());
                try {
                    List<Address> addresses = geocoderDestination.getFromLocation(Double.parseDouble(DestinationLat),
                            Double.parseDouble(DestinationLong), 1);
                    if (addresses != null) {
                        Address returnedAddress = addresses.get(0);
                        StringBuilder strReturnedAddress = new StringBuilder();
                        for (int j = 0; j <= returnedAddress.getMaxAddressLineIndex(); j++) {
                            strReturnedAddress.append(returnedAddress.getAddressLine(j));
                        }
                        streetAddress = strReturnedAddress.toString();
                    }
                } catch (IOException e) {
                }

                myDropUpLocation.setText(streetAddress);
                mMap.addMarker(new MarkerOptions().position(new LatLng(Double.parseDouble(DestinationLat),
                        Double.parseDouble(DestinationLong))).icon(BitmapDescriptorFactory.
                        fromResource(R.drawable.ic_marker)));
            }

            if (!SourceLat.isEmpty() && !DestinationLat.isEmpty()) {
                reestimateDateandTime.setVisibility(View.VISIBLE);
                add.setVisibility(View.GONE);
                btnCompareRide.setVisibility(View.VISIBLE);
                drawRoute();

            }


        } else {

            Geocoder geocoder = new Geocoder(HomeActivity.this, Locale.getDefault());
            try {
                List<Address> addresses = geocoder.getFromLocation(currentLatitude, currentLongitude, 1);
                if (addresses != null) {
                    Address returnedAddress = addresses.get(0);
                    StringBuilder strReturnedAddress = new StringBuilder();
                    for (int j = 0; j <= returnedAddress.getMaxAddressLineIndex(); j++) {
                        strReturnedAddress.append(returnedAddress.getAddressLine(j));
                    }
                    streetAddress = strReturnedAddress.toString();
                }
            } catch (IOException e) {
            }

            if (SourceLat.isEmpty()) {
                sharedpreferences.edit().putString("SourceLat", String.valueOf(currentLatitude)).commit();
                sharedpreferences.edit().putString("SourceLong", String.valueOf(currentLongitude)).commit();

            }
            myCurrentLocation.setText(streetAddress);
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(currentLatitude, currentLongitude), 13.0f));

            mMap.addMarker(new MarkerOptions().position(new LatLng(currentLatitude,
                    currentLongitude)).icon(BitmapDescriptorFactory.
                    fromResource(R.drawable.ic_marker)));
        }


    }

    private void drawRoute() {


        LatLng mOrigin = new LatLng(Double.parseDouble(SourceLat), Double.parseDouble(SourceLong));
        LatLng mDestination = new LatLng(Double.parseDouble(DestinationLat), Double.parseDouble(DestinationLong));

        String url = getDirectionsUrl(mOrigin, mDestination);

        DownloadTask downloadTask = new DownloadTask();

        downloadTask.execute(url);
    }

    private String getDirectionsUrl(LatLng mOrigin, LatLng mDestination) {

        String str_origin = "origin=" + mOrigin.latitude + "," + mOrigin.longitude;
        String str_dest = "destination=" + mDestination.latitude + "," + mDestination.longitude;

        // Key
        String key = "key=" + getString(R.string.google_maps_key);

        // Building the parameters to the web service
        String parameters = str_origin + "&" + str_dest + "&" + key;

        // Output format
        String output = "json";

        // Building the url to the web service
        String url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters;

        return url;
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        myYear = year;
        myday = dayOfMonth;
        myMonth = month + 1;
        Calendar c = Calendar.getInstance();
        hour = c.get(Calendar.HOUR);
        minute = c.get(Calendar.MINUTE);
        AMorPM = c.get(Calendar.AM_PM);
        TimePickerDialog timePickerDialog = new TimePickerDialog(HomeActivity.this,
                HomeActivity.this, hour, minute, DateFormat.is24HourFormat(this));

        timePickerDialog.show();

    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

        myHour = hourOfDay;
        myMinute = minute;

        String AMorPM;

        if (myHour >= 12) {


            AMorPM = "PM";
            if (myHour == 12) {

            } else {
                myHour = myHour - 12;
            }


        } else {

            if (myHour == 0) {
                myHour = myHour + 12;
            }

            AMorPM = "AM";

        }


        String dmonth = null;
        SimpleDateFormat monthParse = new SimpleDateFormat("MM");
        SimpleDateFormat monthDisplay = new SimpleDateFormat("MMM");
        try {
            dmonth = monthDisplay.format(monthParse.parse(String.valueOf(myMonth)));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        tv_RideScheduled.setText(myday + " " + dmonth + ", " + myHour + ":" + myMinute + " " + AMorPM);

    }

    private class DownloadTask extends AsyncTask<String, Void, String> {

        // Downloading data in non-ui thread
        @Override
        protected String doInBackground(String... url) {

            // For storing data from web service
            String data = "";

            try {
                // Fetching the data from web service
                data = downloadUrl(url[0]);

                Log.d("DownloadTask", "DownloadTask : " + data);
            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }

        // Executes in UI thread, after the execution of
        // doInBackground()
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            ParserTask parserTask = new ParserTask();

            // Invokes the thread for parsing the JSON data
            parserTask.execute(result);
        }
    }

    private String downloadUrl(String strUrl) throws IOException {

        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(strUrl);

            // Creating an http connection to communicate with url
            urlConnection = (HttpURLConnection) url.openConnection();

            // Connecting to url
            urlConnection.connect();

            // Reading data from url
            iStream = urlConnection.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb = new StringBuffer();

            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

            data = sb.toString();

            br.close();

        } catch (Exception e) {
            Log.d("Exception on download", e.toString());
        } finally {
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }

    private class ParserTask extends AsyncTask<String, Integer, List<List<HashMap<String, String>>>> {

        // Parsing the data in non-ui thread
        @Override
        protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {

            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;

            try {
                jObject = new JSONObject(jsonData[0]);
                DirectionsJSONParser parser = new DirectionsJSONParser();


                JSONArray array = jObject.getJSONArray("routes");
                JSONObject routes1 = array.getJSONObject(0);

                JSONArray legs = routes1.getJSONArray("legs");

                JSONObject steps = legs.getJSONObject(0);

                JSONObject distance = steps.getJSONObject("distance");
                JSONObject duration = steps.getJSONObject("duration");

                estDistance = distance.getString("text");
                estTime = duration.getString("text");


                Log.d("Distance", distance.getString("text") + "   " + duration.getString("text"));


                // Starts parsing data
                routes = parser.parse(jObject);


            } catch (Exception e) {
                e.printStackTrace();
            }
            return routes;
        }

        // Executes in UI thread, after the parsing process
        @Override
        protected void onPostExecute(List<List<HashMap<String, String>>> result) {
            ArrayList<LatLng> points = null;
            PolylineOptions lineOptions = null;

            // Traversing through all the routes
            for (int i = 0; i < result.size(); i++) {
                points = new ArrayList<LatLng>();
                lineOptions = new PolylineOptions();

                // Fetching i-th route
                List<HashMap<String, String>> path = result.get(i);

                // Fetching all the points in i-th route
                for (int j = 0; j < path.size(); j++) {
                    HashMap<String, String> point = path.get(j);

                    double lat = Double.parseDouble(point.get("lat"));
                    double lng = Double.parseDouble(point.get("lng"));
                    LatLng position = new LatLng(lat, lng);

                    points.add(position);
                }
                tvEstDistance.setText("Est.Distance " + estDistance);
                tvEstTime.setText("Est.Time " + estTime);
                lineOptions.addAll(points);
                lineOptions.width(8);
                //  lineOptions.color(Color.GREEN);
                lineOptions.color((HomeActivity.this).getResources().getColor(R.color.gradientstartcolor));
            }

            // Drawing polyline in the Google Map for the i-th route
            if (lineOptions != null) {
                if (mPolyline != null) {
                    mPolyline.remove();
                }
                mPolyline = mMap.addPolyline(lineOptions);

            } else
                Toast.makeText(getApplicationContext(), "No route is found", Toast.LENGTH_LONG).show();
        }
    }
}



