package com.example.fairfare.ui.placesdemo.placesAuto;

public class GooglePlacesAutocompleteAdapter {
}
