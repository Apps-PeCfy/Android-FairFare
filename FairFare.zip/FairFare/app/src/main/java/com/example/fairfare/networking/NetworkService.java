package com.example.fairfare.networking;

import com.example.fairfare.ui.Login.pojo.LoginResponsepojo;
import com.example.fairfare.ui.home.pojo.GetSaveLocationResponsePOJO;
import com.example.fairfare.ui.home.pojo.SaveLocationResponsePojo;
import com.example.fairfare.ui.otp.pojo.VerifyOTPResponsePojo;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface NetworkService {
    @FormUrlEncoded
    @POST("sendOtp")
    Call<LoginResponsepojo> login(@Field("phone_no") String phoneno,
                                  @Field("type") String type,
                                  @Field("device_type") String device_type,
                                  @Field("login_type") String login_type,
                                  @Field("country_phone_code") String logcountry_phone_codein_type,
                                  @Field("name") String name,
                                  @Field("email") String email,
                                  @Field("tokan") String tokan);


    @FormUrlEncoded
    @POST("socialLogin")
    Call<LoginResponsepojo> sociallogin(@Field("device_type") String device_type,
                                        @Field("login_type") String login_type,
                                        @Field("name") String name,
                                        @Field("provider_id") String provider_id,
                                        @Field("token") String token,
                                        @Field("email") String email);


    @FormUrlEncoded
    @POST("verifyOtp")
    Call<VerifyOTPResponsePojo> verifyOtp(@Field("phone_no") String phoneno,
                                          @Field("type") String type,
                                          @Field("device_type") String device_type,
                                          @Field("login_type") String login_type,
                                          @Field("country_phone_code") String logcountry_phone_codein_type,
                                          @Field("name") String name,
                                          @Field("email") String email,
                                          @Field("gender") String gender,
                                          @Field("otp") String otp);


    @FormUrlEncoded
    @POST("saveLocation")
    Call<SaveLocationResponsePojo> SaveLocation(@Header("Authorization") String header,
                                                @Field("place_id") String place_id,
                                                @Field("city") String city,
                                                @Field("state") String state,
                                                @Field("country") String country,
                                                @Field("full_address") String full_address);


    @GET("getSaveLocation")
    Call<GetSaveLocationResponsePOJO> getSavedLocation(@Header("Authorization") String header);


}
