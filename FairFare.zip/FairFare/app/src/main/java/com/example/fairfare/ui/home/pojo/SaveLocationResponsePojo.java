package com.example.fairfare.ui.home.pojo;

import com.google.gson.annotations.SerializedName;

public class SaveLocationResponsePojo{

	@SerializedName("data")
	private Data data;

	@SerializedName("message")
	private String message;

	public void setData(Data data){
		this.data = data;
	}

	public Data getData(){
		return data;
	}

	public void setMessage(String message){
		this.message = message;
	}

	public String getMessage(){
		return message;
	}

	@Override
 	public String toString(){
		return 
			"SaveLocationResponsePojo{" + 
			"data = '" + data + '\'' + 
			",message = '" + message + '\'' + 
			"}";
		}










	public class Data{

		@SerializedName("country")
		private String country;

		@SerializedName("updated_at")
		private String updatedAt;

		@SerializedName("city")
		private String city;

		@SerializedName("user_id")
		private int userId;

		@SerializedName("created_at")
		private String createdAt;

		@SerializedName("state")
		private String state;

		@SerializedName("full_address")
		private String fullAddress;

		@SerializedName("id")
		private int id;

		@SerializedName("type")
		private String type;

		@SerializedName("place_id")
		private String placeId;

		public void setCountry(String country){
			this.country = country;
		}

		public String getCountry(){
			return country;
		}

		public void setUpdatedAt(String updatedAt){
			this.updatedAt = updatedAt;
		}

		public String getUpdatedAt(){
			return updatedAt;
		}

		public void setCity(String city){
			this.city = city;
		}

		public String getCity(){
			return city;
		}

		public void setUserId(int userId){
			this.userId = userId;
		}

		public int getUserId(){
			return userId;
		}

		public void setCreatedAt(String createdAt){
			this.createdAt = createdAt;
		}

		public String getCreatedAt(){
			return createdAt;
		}

		public void setState(String state){
			this.state = state;
		}

		public String getState(){
			return state;
		}

		public void setFullAddress(String fullAddress){
			this.fullAddress = fullAddress;
		}

		public String getFullAddress(){
			return fullAddress;
		}

		public void setId(int id){
			this.id = id;
		}

		public int getId(){
			return id;
		}

		public void setType(String type){
			this.type = type;
		}

		public String getType(){
			return type;
		}

		public void setPlaceId(String placeId){
			this.placeId = placeId;
		}

		public String getPlaceId(){
			return placeId;
		}

		@Override
		public String toString(){
			return
					"Data{" +
							"country = '" + country + '\'' +
							",updated_at = '" + updatedAt + '\'' +
							",city = '" + city + '\'' +
							",user_id = '" + userId + '\'' +
							",created_at = '" + createdAt + '\'' +
							",state = '" + state + '\'' +
							",full_address = '" + fullAddress + '\'' +
							",id = '" + id + '\'' +
							",type = '" + type + '\'' +
							",place_id = '" + placeId + '\'' +
							"}";
		}
	}
}